<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>Verify Appointment Cancellation</description>
   <name>TCAPPO003</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>fbd63561-0681-4c5a-b8ab-c0d6fb3740f2</testSuiteGuid>
   <testCaseLink>
      <guid>dc4ae23d-8eff-4331-8ba7-edb0388a99f5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>1a1d0b52-eae8-4ceb-a2bd-89a86bfbed8e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Make Appointment</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0e5aa32b-97ea-4a1a-9510-0307f979df70</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Verify Go Hompage</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
