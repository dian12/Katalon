<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>Verify Invalid Login Attempt</description>
   <name>TCLOG003</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>8c80cd10-012a-4b02-b3ad-2f737d2f5c72</testSuiteGuid>
   <testCaseLink>
      <guid>8ca7acf1-1a7a-4ee8-8396-850db9431b71</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/LoginFalse</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>62803b6a-3e76-444c-b36c-48a9e91fee4f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Verify Error Message Login Failed</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
