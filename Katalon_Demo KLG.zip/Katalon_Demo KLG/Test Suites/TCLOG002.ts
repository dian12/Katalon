<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>Verify Logout Functionality</description>
   <name>TCLOG002</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>cfb2728e-c139-4aba-b95d-152245c58601</testSuiteGuid>
   <testCaseLink>
      <guid>2f7d6ef1-4b44-4187-9427-1f473a93b570</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>5d3abc7e-0d83-4bec-b5a2-892404853763</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Logout</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>bec22cf4-385f-4c32-9ac5-fa75fdd1e76e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Verify Redirect to Login Page</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
