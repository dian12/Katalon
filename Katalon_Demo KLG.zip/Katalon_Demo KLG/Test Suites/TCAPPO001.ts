<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>Verify Successful Appointment Booking</description>
   <name>TCAPPO001</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>f62181eb-ce66-4f2f-9ec9-5e83cf69be63</testSuiteGuid>
   <testCaseLink>
      <guid>6c93e003-7bf0-4084-9952-3999de42921a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a5debac1-7feb-4242-9375-16f65e0f1ebc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Make Appointment</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8dcc03f4-2d20-4dcf-b17b-7e0eac473997</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Verify Message is displayed on appointment</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
