<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>Verify Successful Login</description>
   <name>TCLOG001</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>dcc59f87-f0e2-414a-b69d-f273eeaf8481</testSuiteGuid>
   <testCaseLink>
      <guid>b707d28c-8abb-46c0-9f3b-152277344013</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>158c88ed-cd52-47e3-8433-d6ee2a0af65b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Verify User Redirect Succes Login</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
