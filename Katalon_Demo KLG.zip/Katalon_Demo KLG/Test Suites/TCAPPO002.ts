<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>Verify Invalid Appointment Booking because the date was not filled in</description>
   <name>TCAPPO002</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>849bddac-69ba-418a-a956-83cef9dfcabe</testSuiteGuid>
   <testCaseLink>
      <guid>d91ffba9-4e18-47fa-833e-4b54486ff478</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3783c2d0-a024-4021-8750-d3de92705a8d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Make Appointment - Blank Date</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e7564fed-0546-44e0-aeee-92b02fdb197a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Verify failed make appointment</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
