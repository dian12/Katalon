<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>Verify Can Access History Appointment</description>
   <name>TCAPPO004</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>4cc47179-d905-4bfc-aa0d-1955123c7e0c</testSuiteGuid>
   <testCaseLink>
      <guid>6f13a6aa-7574-4438-8cdc-081eb2fb3abf</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d0792bed-403c-4022-9c59-1a4cad44629d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Make Appointment</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>4e87b8bd-a3e7-4188-99e8-a3781d95625f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/History</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
